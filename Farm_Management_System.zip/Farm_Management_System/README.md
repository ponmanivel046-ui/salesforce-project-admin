# Farm Management System

A complete academic Farm Management System built with Python Flask and SQLite.

## Features
- User registration and login
- Farm and field management
- Crop and season tracking
- Seeds, fertilizer, pesticide and resource records
- Farming activity and irrigation tracking
- Worker management
- Expense management
- Harvest management
- Crop sales management
- Dashboard with income, expense and profit
- Reports for expenses and crop production
- SQLite database with foreign-key relationships
- Responsive web interface

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

## Installation

Open a terminal inside this project folder:

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Then open:

http://127.0.0.1:5000

## Demo Login

Email: `admin@farm.local`

Password: `admin123`

Change the secret key and demo password before deploying publicly.

## Database

The SQLite database `farm_management.db` is automatically created on first run.

## Project Modules

Dashboard, Farms, Fields, Crops, Resources, Activities, Workers, Expenses, Harvests, Sales and Reports.

## Academic Notes

This project is suitable as a starting point for a college mini-project/final-year project. You can extend it with weather APIs, IoT soil sensors, GPS field maps, notifications, mobile support and AI-based crop recommendations.
