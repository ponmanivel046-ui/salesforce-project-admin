document.addEventListener("DOMContentLoaded", () => {
  const q = document.getElementById("quantity");
  const p = document.getElementById("price");
  if (q && p) {
    [q,p].forEach(x => x.addEventListener("input", () => {
      const old = document.getElementById("sale-preview");
      if (old) old.remove();
      const box = document.createElement("small");
      box.id = "sale-preview";
      box.textContent = "Estimated total: ₹" + ((parseFloat(q.value)||0)*(parseFloat(p.value)||0)).toFixed(2);
      p.parentNode.appendChild(box);
    }));
  }
});