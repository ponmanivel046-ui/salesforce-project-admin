from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import date

app = Flask(__name__)
app.secret_key = "farm-management-system-change-this-secret-key"
DB = "farm_management.db"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Admin'
    );
    CREATE TABLE IF NOT EXISTS farms (
        farm_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farm_name TEXT NOT NULL,
        owner_id INTEGER,
        location TEXT,
        total_area REAL DEFAULT 0,
        FOREIGN KEY(owner_id) REFERENCES users(user_id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS fields (
        field_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farm_id INTEGER NOT NULL,
        field_name TEXT NOT NULL,
        area REAL DEFAULT 0,
        soil_type TEXT,
        status TEXT DEFAULT 'Active',
        FOREIGN KEY(farm_id) REFERENCES farms(farm_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS crops (
        crop_id INTEGER PRIMARY KEY AUTOINCREMENT,
        field_id INTEGER NOT NULL,
        crop_name TEXT NOT NULL,
        variety TEXT,
        season TEXT,
        sowing_date TEXT,
        harvest_date TEXT,
        status TEXT DEFAULT 'Growing',
        FOREIGN KEY(field_id) REFERENCES fields(field_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS resources (
        resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        quantity REAL DEFAULT 0,
        unit TEXT,
        purchase_cost REAL DEFAULT 0,
        purchase_date TEXT
    );
    CREATE TABLE IF NOT EXISTS activities (
        activity_id INTEGER PRIMARY KEY AUTOINCREMENT,
        field_id INTEGER NOT NULL,
        activity_type TEXT NOT NULL,
        activity_date TEXT NOT NULL,
        description TEXT,
        FOREIGN KEY(field_id) REFERENCES fields(field_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS workers (
        worker_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farm_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        phone TEXT,
        role TEXT,
        wage REAL DEFAULT 0,
        FOREIGN KEY(farm_id) REFERENCES farms(farm_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS expenses (
        expense_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farm_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        expense_date TEXT NOT NULL,
        description TEXT,
        FOREIGN KEY(farm_id) REFERENCES farms(farm_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS harvests (
        harvest_id INTEGER PRIMARY KEY AUTOINCREMENT,
        crop_id INTEGER NOT NULL,
        harvest_date TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT,
        quality TEXT,
        storage TEXT,
        FOREIGN KEY(crop_id) REFERENCES crops(crop_id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS sales (
        sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
        harvest_id INTEGER NOT NULL,
        buyer TEXT NOT NULL,
        quantity REAL NOT NULL,
        price REAL NOT NULL,
        total_amount REAL NOT NULL,
        sale_date TEXT NOT NULL,
        FOREIGN KEY(harvest_id) REFERENCES harvests(harvest_id) ON DELETE CASCADE
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        conn.execute(
            "INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
            ("Administrator", "admin@farm.local", generate_password_hash("admin123"), "Admin")
        )
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def delete_record(table, pk, value):
    conn = get_db()
    conn.execute(f"DELETE FROM {table} WHERE {pk} = ?", (value,))
    conn.commit()
    conn.close()

@app.context_processor
def inject_globals():
    return {"today": date.today().isoformat(), "logged_in": "user_id" in session}

@app.route("/")
def index():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"]
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["user_id"]
            session["user_name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name, email, password = request.form["name"].strip(), request.form["email"].strip(), request.form["password"]
        conn = get_db()
        try:
            conn.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                         (name, email, generate_password_hash(password)))
            conn.commit()
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    stats = {
        "farms": conn.execute("SELECT COUNT(*) FROM farms").fetchone()[0],
        "fields": conn.execute("SELECT COUNT(*) FROM fields").fetchone()[0],
        "crops": conn.execute("SELECT COUNT(*) FROM crops").fetchone()[0],
        "workers": conn.execute("SELECT COUNT(*) FROM workers").fetchone()[0],
        "harvest": conn.execute("SELECT COALESCE(SUM(quantity),0) FROM harvests").fetchone()[0],
        "expenses": conn.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0],
        "income": conn.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales").fetchone()[0],
    }
    stats["profit"] = stats["income"] - stats["expenses"]
    recent_sales = conn.execute("""SELECT s.*, h.unit, c.crop_name
        FROM sales s JOIN harvests h ON s.harvest_id=h.harvest_id
        JOIN crops c ON h.crop_id=c.crop_id ORDER BY s.sale_id DESC LIMIT 5""").fetchall()
    conn.close()
    return render_template("dashboard.html", stats=stats, recent_sales=recent_sales)

@app.route("/farms", methods=["GET","POST"])
@login_required
def farms():
    conn = get_db()
    if request.method == "POST":
        conn.execute("INSERT INTO farms(farm_name,owner_id,location,total_area) VALUES(?,?,?,?)",
                     (request.form["farm_name"], session["user_id"], request.form["location"],
                      request.form["total_area"] or 0))
        conn.commit()
        flash("Farm added successfully.", "success")
        return redirect(url_for("farms"))
    rows = conn.execute("""SELECT f.*, u.name AS owner FROM farms f
                           LEFT JOIN users u ON f.owner_id=u.user_id ORDER BY f.farm_id DESC""").fetchall()
    conn.close()
    return render_template("farms.html", farms=rows)

@app.route("/farms/delete/<int:id>")
@login_required
def delete_farm(id):
    delete_record("farms","farm_id",id); flash("Farm deleted.", "success"); return redirect(url_for("farms"))

@app.route("/fields", methods=["GET","POST"])
@login_required
def fields():
    conn = get_db()
    if request.method == "POST":
        conn.execute("INSERT INTO fields(farm_id,field_name,area,soil_type,status) VALUES(?,?,?,?,?)",
                     (request.form["farm_id"], request.form["field_name"], request.form["area"] or 0,
                      request.form["soil_type"], request.form["status"]))
        conn.commit(); flash("Field added.", "success"); return redirect(url_for("fields"))
    rows = conn.execute("""SELECT f.*, fa.farm_name FROM fields f JOIN farms fa ON f.farm_id=fa.farm_id
                           ORDER BY f.field_id DESC""").fetchall()
    farms_list = conn.execute("SELECT * FROM farms ORDER BY farm_name").fetchall()
    conn.close()
    return render_template("fields.html", fields=rows, farms=farms_list)

@app.route("/fields/delete/<int:id>")
@login_required
def delete_field(id):
    delete_record("fields","field_id",id); flash("Field deleted.", "success"); return redirect(url_for("fields"))

@app.route("/crops", methods=["GET","POST"])
@login_required
def crops():
    conn = get_db()
    if request.method == "POST":
        conn.execute("""INSERT INTO crops(field_id,crop_name,variety,season,sowing_date,harvest_date,status)
                        VALUES(?,?,?,?,?,?,?)""",
                     (request.form["field_id"],request.form["crop_name"],request.form["variety"],
                      request.form["season"],request.form["sowing_date"],request.form["harvest_date"],
                      request.form["status"]))
        conn.commit(); flash("Crop added.", "success"); return redirect(url_for("crops"))
    rows = conn.execute("""SELECT c.*, f.field_name, fa.farm_name FROM crops c
                           JOIN fields f ON c.field_id=f.field_id JOIN farms fa ON f.farm_id=fa.farm_id
                           ORDER BY c.crop_id DESC""").fetchall()
    fields_list = conn.execute("""SELECT f.*, fa.farm_name FROM fields f JOIN farms fa ON f.farm_id=fa.farm_id
                                  ORDER BY fa.farm_name,f.field_name""").fetchall()
    conn.close()
    return render_template("crops.html", crops=rows, fields=fields_list)

@app.route("/crops/delete/<int:id>")
@login_required
def delete_crop(id):
    delete_record("crops","crop_id",id); flash("Crop deleted.", "success"); return redirect(url_for("crops"))

@app.route("/resources", methods=["GET","POST"])
@login_required
def resources():
    conn = get_db()
    if request.method == "POST":
        conn.execute("""INSERT INTO resources(name,category,quantity,unit,purchase_cost,purchase_date)
                        VALUES(?,?,?,?,?,?)""",
                     (request.form["name"],request.form["category"],request.form["quantity"] or 0,
                      request.form["unit"],request.form["purchase_cost"] or 0,request.form["purchase_date"]))
        conn.commit(); flash("Resource added.", "success"); return redirect(url_for("resources"))
    rows = conn.execute("SELECT * FROM resources ORDER BY resource_id DESC").fetchall()
    conn.close()
    return render_template("resources.html", resources=rows)

@app.route("/resources/delete/<int:id>")
@login_required
def delete_resource(id):
    delete_record("resources","resource_id",id); flash("Resource deleted.", "success"); return redirect(url_for("resources"))

@app.route("/activities", methods=["GET","POST"])
@login_required
def activities():
    conn = get_db()
    if request.method == "POST":
        conn.execute("""INSERT INTO activities(field_id,activity_type,activity_date,description)
                        VALUES(?,?,?,?)""",
                     (request.form["field_id"],request.form["activity_type"],
                      request.form["activity_date"],request.form["description"]))
        conn.commit(); flash("Activity recorded.", "success"); return redirect(url_for("activities"))
    rows = conn.execute("""SELECT a.*, f.field_name, fa.farm_name FROM activities a
                           JOIN fields f ON a.field_id=f.field_id JOIN farms fa ON f.farm_id=fa.farm_id
                           ORDER BY a.activity_id DESC""").fetchall()
    fields_list = conn.execute("""SELECT f.*, fa.farm_name FROM fields f JOIN farms fa ON f.farm_id=fa.farm_id
                                  ORDER BY fa.farm_name,f.field_name""").fetchall()
    conn.close()
    return render_template("activities.html", activities=rows, fields=fields_list)

@app.route("/activities/delete/<int:id>")
@login_required
def delete_activity(id):
    delete_record("activities","activity_id",id); flash("Activity deleted.", "success"); return redirect(url_for("activities"))

@app.route("/workers", methods=["GET","POST"])
@login_required
def workers():
    conn = get_db()
    if request.method == "POST":
        conn.execute("INSERT INTO workers(farm_id,name,phone,role,wage) VALUES(?,?,?,?,?)",
                     (request.form["farm_id"],request.form["name"],request.form["phone"],
                      request.form["role"],request.form["wage"] or 0))
        conn.commit(); flash("Worker added.", "success"); return redirect(url_for("workers"))
    rows = conn.execute("""SELECT w.*, f.farm_name FROM workers w JOIN farms f ON w.farm_id=f.farm_id
                           ORDER BY w.worker_id DESC""").fetchall()
    farms_list = conn.execute("SELECT * FROM farms ORDER BY farm_name").fetchall()
    conn.close()
    return render_template("workers.html", workers=rows, farms=farms_list)

@app.route("/workers/delete/<int:id>")
@login_required
def delete_worker(id):
    delete_record("workers","worker_id",id); flash("Worker deleted.", "success"); return redirect(url_for("workers"))

@app.route("/expenses", methods=["GET","POST"])
@login_required
def expenses():
    conn = get_db()
    if request.method == "POST":
        conn.execute("""INSERT INTO expenses(farm_id,category,amount,expense_date,description)
                        VALUES(?,?,?,?,?)""",
                     (request.form["farm_id"],request.form["category"],request.form["amount"],
                      request.form["expense_date"],request.form["description"]))
        conn.commit(); flash("Expense recorded.", "success"); return redirect(url_for("expenses"))
    rows = conn.execute("""SELECT e.*, f.farm_name FROM expenses e JOIN farms f ON e.farm_id=f.farm_id
                           ORDER BY e.expense_id DESC""").fetchall()
    farms_list = conn.execute("SELECT * FROM farms ORDER BY farm_name").fetchall()
    total = conn.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    conn.close()
    return render_template("expenses.html", expenses=rows, farms=farms_list, total=total)

@app.route("/expenses/delete/<int:id>")
@login_required
def delete_expense(id):
    delete_record("expenses","expense_id",id); flash("Expense deleted.", "success"); return redirect(url_for("expenses"))

@app.route("/harvests", methods=["GET","POST"])
@login_required
def harvests():
    conn = get_db()
    if request.method == "POST":
        conn.execute("""INSERT INTO harvests(crop_id,harvest_date,quantity,unit,quality,storage)
                        VALUES(?,?,?,?,?,?)""",
                     (request.form["crop_id"],request.form["harvest_date"],request.form["quantity"],
                      request.form["unit"],request.form["quality"],request.form["storage"]))
        conn.commit(); flash("Harvest recorded.", "success"); return redirect(url_for("harvests"))
    rows = conn.execute("""SELECT h.*, c.crop_name, f.field_name FROM harvests h
                           JOIN crops c ON h.crop_id=c.crop_id JOIN fields f ON c.field_id=f.field_id
                           ORDER BY h.harvest_id DESC""").fetchall()
    crops_list = conn.execute("SELECT crop_id,crop_name FROM crops ORDER BY crop_name").fetchall()
    conn.close()
    return render_template("harvests.html", harvests=rows, crops=crops_list)

@app.route("/harvests/delete/<int:id>")
@login_required
def delete_harvest(id):
    delete_record("harvests","harvest_id",id); flash("Harvest deleted.", "success"); return redirect(url_for("harvests"))

@app.route("/sales", methods=["GET","POST"])
@login_required
def sales():
    conn = get_db()
    if request.method == "POST":
        quantity = float(request.form["quantity"])
        price = float(request.form["price"])
        conn.execute("""INSERT INTO sales(harvest_id,buyer,quantity,price,total_amount,sale_date)
                        VALUES(?,?,?,?,?,?)""",
                     (request.form["harvest_id"],request.form["buyer"],quantity,price,quantity*price,
                      request.form["sale_date"]))
        conn.commit(); flash("Sale recorded.", "success"); return redirect(url_for("sales"))
    rows = conn.execute("""SELECT s.*, h.unit, c.crop_name FROM sales s
                           JOIN harvests h ON s.harvest_id=h.harvest_id
                           JOIN crops c ON h.crop_id=c.crop_id ORDER BY s.sale_id DESC""").fetchall()
    harvests_list = conn.execute("""SELECT h.harvest_id,h.quantity,h.unit,c.crop_name
                                    FROM harvests h JOIN crops c ON h.crop_id=c.crop_id
                                    ORDER BY h.harvest_id DESC""").fetchall()
    total = conn.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales").fetchone()[0]
    conn.close()
    return render_template("sales.html", sales=rows, harvests=harvests_list, total=total)

@app.route("/sales/delete/<int:id>")
@login_required
def delete_sale(id):
    delete_record("sales","sale_id",id); flash("Sale deleted.", "success"); return redirect(url_for("sales"))

@app.route("/reports")
@login_required
def reports():
    conn = get_db()
    expense_by_category = conn.execute("""SELECT category, SUM(amount) amount FROM expenses
                                          GROUP BY category ORDER BY amount DESC""").fetchall()
    crop_production = conn.execute("""SELECT c.crop_name, SUM(h.quantity) quantity, h.unit
                                      FROM harvests h JOIN crops c ON h.crop_id=c.crop_id
                                      GROUP BY c.crop_id ORDER BY quantity DESC""").fetchall()
    income = conn.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales").fetchone()[0]
    expense = conn.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    conn.close()
    return render_template("reports.html", expense_by_category=expense_by_category,
                           crop_production=crop_production, income=income, expense=expense,
                           profit=income-expense)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
